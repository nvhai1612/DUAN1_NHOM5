/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository.Impl;

import DomainModel.SanPham;
import Repository.ISanPhamRepos;
import Utiliti.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class SanPhamRepos implements ISanPhamRepos {

    @Override
    public ArrayList<SanPham> getListFormDB() {
        ArrayList<SanPham> lsSanPham = new ArrayList<>();
        Connection cn = DBConnection.getConnection();
        String sql = "Select * from SANPHAM";
        Statement stm;
        try {
            stm = cn.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                SanPham sp = new SanPham();
                sp.setId(rs.getString("ID"));
                sp.setMa(rs.getString("MASP"));
                sp.setTen(rs.getString("TENSP"));
                lsSanPham.add(sp);
            }
        } catch (Exception e) {
        }
        return lsSanPham;
    }

    @Override
    public Integer add(SanPham kc) {
        Integer row = null;
        String sql = "Insert into SANPHAM(MASP,TENSP) values(?,?)";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getMa());
            pstm.setString(2, kc.getTen());

            //thuc thi statement : insert =>excuteUpdate
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

    @Override
    public Integer update(SanPham kc) {
        Integer row = null;
        String sql = "update SANPHAM set TENSP = ? where MASP = ?";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getTen());
            pstm.setString(2, kc.getMa());
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

}
