/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository.Impl;

import DomainModel.ChucVu;
import Repository.IChucVuRepos;
import Utiliti.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class ChucVuRepos implements IChucVuRepos {

    @Override
    public ArrayList<ChucVu> getListFormDB() {
        ArrayList<ChucVu> lsChucVu = new ArrayList<>();
        Connection cn = DBConnection.getConnection();
        String sql = "Select * from CHUCVU";
        Statement stm;
        try {
            stm = cn.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                ChucVu cv = new ChucVu();
                cv.setId(rs.getString("ID"));
                cv.setMa(rs.getString("MACV"));
                cv.setTen(rs.getString("TENCV"));
                lsChucVu.add(cv);
            }
        } catch (Exception e) {
        }
        return lsChucVu;
    }

    @Override
    public Integer add(ChucVu kc) {
        Integer row = null;
        String sql = "Insert into CHUCVU(MACV,TENCV) values(?,?)";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getMa());
            pstm.setString(2, kc.getTen());

            //thuc thi statement : insert =>excuteUpdate
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

    @Override
    public Integer update(ChucVu kc) {
        Integer row = null;
        String sql = "update CHUCVU set TENCV = ? where MACV = ?";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getTen());
            pstm.setString(2, kc.getMa());
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

}
