/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository.Impl;

import DomainModel.MauSac;
import Repository.IMauSacRepos;
import Utiliti.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class MauSacRepos implements IMauSacRepos{
    
    @Override
    public ArrayList<MauSac> getListFormDB() {
           ArrayList<MauSac> lsMauSac = new ArrayList<>();
        Connection cn = DBConnection.getConnection();
        String sql = "Select * from MAUSAC";
        Statement stm;
        try {
            stm = cn.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                MauSac ms = new MauSac();
                ms.setId(rs.getString("ID"));
                ms.setMa(rs.getString("MAMS"));
                ms.setTen(rs.getString("TENMS"));
                lsMauSac.add(ms);
            }
        } catch (Exception e) {
        }
        return lsMauSac;
    }

    @Override
    public Integer add(MauSac kc) {
         Integer row = null;
        String sql = "Insert into MAUSAC(MAMS,TENMS) values(?,?)";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getMa());
            pstm.setString(2, kc.getTen());

            //thuc thi statement : insert =>excuteUpdate
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

    @Override
    public Integer update(MauSac kc) {
        Integer row = null;
        String sql = "update MAUSAC set TENMS = ? where MAMS = ?";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getTen());
            pstm.setString(2, kc.getMa());
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }
    
}
