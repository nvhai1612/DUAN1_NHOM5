/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository.Impl;

import DomainModel.KichCo;
import Repository.IKichCoRepos;
import Utiliti.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class KichCoRepos implements IKichCoRepos{
    
    @Override
    public ArrayList<KichCo> getListFormDB() {
         ArrayList<KichCo> lsKichCo = new ArrayList<>();
        Connection cn = DBConnection.getConnection();
        String sql = "Select * from KICHCO";
        Statement stm;
        try {
            stm = cn.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                KichCo cc = new KichCo();
                cc.setId(rs.getString("ID"));
                cc.setMa(rs.getString("MAKC"));
                cc.setTen(rs.getString("TENKC"));
                lsKichCo.add(cc);
            }
        } catch (Exception e) {
        }
        return lsKichCo;
    }

    @Override
    public Integer add(KichCo kc) {
        Integer row = null;
        String sql = "Insert into KICHCO(MAKC,TENKC) values(?,?)";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getMa());
            pstm.setString(2, kc.getTen());

            //thuc thi statement : insert =>excuteUpdate
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }

    @Override
    public Integer update(KichCo kc) {
        Integer row = null;
        String sql = "update KICHCO set TENKC = ? where MAKC = ?";
        Connection cn = DBConnection.getConnection();
        try {
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, kc.getTen());
            pstm.setString(2, kc.getMa());
            row = pstm.executeUpdate();
        } catch (Exception e) {
        }
        return row;
    }
    
}
