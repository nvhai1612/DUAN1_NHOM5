/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import DomainModel.SanPham;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public interface ISanPhamRepos {
     public ArrayList<SanPham> getListFormDB();

    public Integer add(SanPham kc);

    public Integer update(SanPham kc);
}
