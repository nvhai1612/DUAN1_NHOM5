/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import DomainModel.KichCo;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public interface IKichCoRepos {

    public ArrayList<KichCo> getListFormDB();

    public Integer add(KichCo kc);

    public Integer update(KichCo kc);

}
