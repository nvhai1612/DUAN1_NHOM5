/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import DomainModel.MauSac;
import ViewModel.MauSacVM;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public interface IMauSacService {
      ArrayList<MauSacVM> getAll();
    ArrayList<MauSac>getAllDoMain();
    void add(MauSac kc);
    void update(MauSac kc);
}
