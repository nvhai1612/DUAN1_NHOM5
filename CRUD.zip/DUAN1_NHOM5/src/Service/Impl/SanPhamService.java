/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service.Impl;

import DomainModel.SanPham;
import Repository.Impl.SanPhamRepos;
import Service.ISanPhamService;
import ViewModel.SanPhamVM;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class SanPhamService implements ISanPhamService{
        private SanPhamRepos repos = new SanPhamRepos();
    @Override
    public ArrayList<SanPhamVM> getAll() {
        ArrayList<SanPham> listKC = repos.getListFormDB();
        ArrayList<SanPhamVM> listKCVM = new ArrayList<>();
        for(SanPham kc : listKC){
            SanPhamVM nvvm = new 
        SanPhamVM(kc.getId(),kc.getMa(),kc.getTen());
            listKCVM.add(nvvm);
        }
        return listKCVM;
    }

    @Override
    public ArrayList<SanPham> getAllDoMain() {
        return repos.getListFormDB();
    }

    @Override
    public void add(SanPham kc) {
        repos.add(kc);
    }

    @Override
    public void update(SanPham kc) {
        repos.update(kc);
    }
    
}
