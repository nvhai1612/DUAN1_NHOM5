/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service.Impl;

import DomainModel.ChucVu;
import Repository.Impl.ChucVuRepos;
import Service.IChucVuService;
import ViewModel.ChucVuVM;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class ChucVuService implements IChucVuService{
    private ChucVuRepos repos = new ChucVuRepos();
    @Override
    public ArrayList<ChucVuVM> getAll() {
         ArrayList<ChucVu> listKC = repos.getListFormDB();
        ArrayList<ChucVuVM> listKCVM = new ArrayList<>();
        for(ChucVu kc : listKC){
            ChucVuVM nvvm = new 
        ChucVuVM(kc.getId(),kc.getMa(),kc.getTen());
            listKCVM.add(nvvm);
        }
        return listKCVM;
    }

    @Override
    public ArrayList<ChucVu> getAllDoMain() {
        return repos.getListFormDB();
    }

    @Override
    public void add(ChucVu kc) {
        repos.add(kc);
    }

    @Override
    public void update(ChucVu kc) {
        repos.update(kc);
    }
    
}
