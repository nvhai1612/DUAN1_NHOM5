/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service.Impl;

import DomainModel.KichCo;
import Repository.Impl.KichCoRepos;
import Service.IKichCoService;
import ViewModel.KichCoVM;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class KichCoService implements IKichCoService{
    private KichCoRepos kichCoRepos = new KichCoRepos();

    public KichCoService() {
    }
    
    @Override
    public ArrayList<KichCoVM> getAll() {
       ArrayList<KichCo> listKC = kichCoRepos.getListFormDB();
        ArrayList<KichCoVM> listKCVM = new ArrayList<>();
        for(KichCo kc : listKC){
            KichCoVM nvvm = new 
        KichCoVM(kc.getId(),kc.getMa(),kc.getTen());
            listKCVM.add(nvvm);
        }
        return listKCVM;
    }

    @Override
    public ArrayList<KichCo> getAllDoMain() {
        return kichCoRepos.getListFormDB();
    }

    @Override
    public void add(KichCo kc) {
        kichCoRepos.add(kc);
    }

    @Override
    public void update(KichCo kc) {
        kichCoRepos.update(kc);
    }

   

    
    
}
