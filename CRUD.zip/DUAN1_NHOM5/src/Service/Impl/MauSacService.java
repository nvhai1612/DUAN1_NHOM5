/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service.Impl;

import DomainModel.MauSac;
import Repository.Impl.MauSacRepos;
import Service.IMauSacService;
import ViewModel.MauSacVM;
import java.util.ArrayList;

/**
 *
 * @author kimuc
 */
public class MauSacService implements IMauSacService{
    private MauSacRepos repos = new MauSacRepos();
    @Override
    public ArrayList<MauSacVM> getAll() {
        ArrayList<MauSac> listKC = repos.getListFormDB();
        ArrayList<MauSacVM> listKCVM = new ArrayList<>();
        for(MauSac kc : listKC){
            MauSacVM nvvm = new 
        MauSacVM(kc.getId(),kc.getMa(),kc.getTen());
            listKCVM.add(nvvm);
        }
        return listKCVM;
    }

    @Override
    public ArrayList<MauSac> getAllDoMain() {
        return repos.getListFormDB();
    }

    @Override
    public void add(MauSac kc) {
        repos.add(kc);
    }

    @Override
    public void update(MauSac kc) {
        repos.update(kc);
    }
    
}
